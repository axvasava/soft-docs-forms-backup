/* jshint maxerr: 10000 */

define([
	"jquery",
	"knockout",
	"vmBase",
	"integration",
	"notify",
	"user",
	"template/autosize.min",
	"template/jquery.maskedinput",
	"./liveViewModel.js",
	"package",
	"https://webapps.oaklandcc.edu/cdn/utils/formUtils.js",
	/*-- WARNING: Uncommenting the line of code below will allow you to use Etrieve Extenders on this form.
    Currently, Etrieve Extenders are only compatible with cloud based instances of Etrieve.
    If you are unsure if you can utilize Extenders, please contact your institution's Etrieve Administrator.*/
	"https://softdocscdn.etrieve.cloud/extenders/extenders.min.js",
], function viewmodel(
	$,
	ko,
	vm,
	integration,
	notify,
	user,
	autosize,
	maskedinput,
	liveVM,
	pkg,
	formUtils,
) {
	$(".loading").show();
	//This function is used to set the autosize function on textareas with a class of autosizeareas.
	//Uncomment to use.
	//autosize($('.autosizeareas'));

	/*
    These functions are used to set the masking of fields. There are 3 example classes below you can use.
    If you need to add another row, simple copy one of the examples below and edit the class name and the mask
    */
	$(".maskphone").mask("(999)999-9999? ext:9999");
	$(".maskzip").mask("99999?-9999");
	$(".maskssn").mask("999-99-9999");
	$(".maskCourseSection").mask("aaa-9999");
	/*End masking functions*/

	var formLifecycle = formUtils.createFormLifecycleUtils({
		vm: vm,
		pkg: pkg,
		user: user,
		formUtils: formUtils,
	});

	var requiredIndicators = formLifecycle.requiredIndicators;
	var fieldStateUtils = formLifecycle.fieldStateUtils;
	var fieldValidation = formLifecycle.fieldValidation;

	//Parameters:
	//  $: jQuery object. Additional documentation found at api.jquery.com

	//  ko: knockoutjs object. Additional documentation found at knockoutjs.com

	//  vm: is a base viewmodel object that enables you to interact with observable inputs on the
	//  view.html.  Observables for all inputs, selects, and textareas will be added when the
	//  viewmodel is bound to the view.  vmBase has functions to aid in adding additional observable
	//  properties to itself such as addObservables, addObservableArrays which both take a comma-
	//  separated string of names.

	//  user: The user parameter includes data associated with the current user including isInLibrary,
	//  isInDrafts, isInActivity, isOriginator, DisplayName, UserName, hasGroupOrRole, Email.

	//  integration: has functions for directly calling integration sources configured on the server
	//  integration.first: takes Source Code and an optional Parameter Object, returning a single object
	//  integration.all: takes Source Code and an optional Parameter Object, returning an array of objects
	//  integration.add: takes Source Code and a Parameter Object, returning an array of objects
	//  integration.update: takes Source Code and a Parameter Object, returning an array of objects
	//  integration.delete: takes Source Code and a Parameter Object, returning an array of objects

	//  notify: method that display a toast notification, it requires the next parameters
	//      - toastrType: string indicating the type of toast notification, could have the next values:
	//          - success
	//          - warning
	//          - error
	//      - message: string indicating the message to display on notification
	//      - title: string indicating the title for the notification

	//  pkg: The pkg viewmodel object includes parameters which return properties
	//  around the package and the package state throughout the workflow.
	//  stepCode, stepName, isAtStep, isExporting.

	//The following methods are lifecycle callbacks that will be called as described
	//if they are returned on the viewmodel object, but they are not required.

	//NOTE: if a JavaScript Promise is returned from any Lifecycle Callback, the process will wait until
	//the Promise is resolved before continuing.  Additionally, if an Integration source or any other
	//asynchronous method is called directly within one of these functions, it is required that a Promise
	//be returned in order to guarantee these methods are called in a predictable, sequential manner.

	//Loading Lifecycle Callbacks:
	//Parameters:
	//  source:
	//  If the form is configured to receive integration sources onLoad or onOrigination,
	//  they will be passed on the source parameter. onLoad sources will be available
	//  every time the form is loaded while onOrigination sources will only be available
	//  when user.isInLibrary is true.

	//  inputValues:
	//  inputValues.first(id) takes an input id & returns a single value if one exists.
	//  inputValues.all(id) takes an input id & returns an array of values if any exist.
	//  inputValues.audit(id) takes an input id & returns an array of audit history values if any exist.
	//  inputValues.list is an array of all values sent from the server that will be loaded
	//      into this form after setDefaults and prior to afterLoad.  This should only be needed if
	//      it is necessary to filter on something other than input id.

	function getCatalogYear() {
		var today = new Date();
		var currentYear = today.getFullYear();

		// Catalog year advances every June 1.
		var juneFirst = new Date(currentYear, 5, 1);

		var startYear;

		if (today >= juneFirst) {
			startYear = currentYear + 2;
		} else {
			startYear = currentYear + 1;
		}

		var endYear = (startYear + 1).toString().slice(-2);

		return startYear + "-" + endYear;
	}

	vm.onLoad = function onLoad(source, inputValues) {
		//  This takes place after applyBindings has been called and has added input observables to the
		//  viewmodel (vm) and before values are loaded into the form.  This method is ideal for
		//  populating dropdowns, select options and other operations that need to take place every
		//  time the form is loaded.
		//  WARNING: It is not recommended to set input values during onLoad because it is not guaranteed
		//  to save values to the server.
	};
	vm.setDefaults = function setDefaults(source, inputValues) {
		//  This method is called after values from the server are loaded into the form inputs and before
		//  afterLoad is called.

		//  WARNING: if an integration source is called directly to retrieve values and populate inputs
		//  with default values, setDefaults must return the integration source promise.  If it doesn't,
		//  a form draft may be created every time a user opens the form and more importantly the values
		//  may not be saved to the server.

		var catalogYear = getCatalogYear();

		$("#catalogYear").append(
			$("<option>", {
				value: catalogYear,
				text: catalogYear,
			}),
		);

		vm.catalogYear(catalogYear);

		if (user.isInLibrary) {
		} else {
			//  Input Values set here will be saved to the server immediately.
			//  CAUTION: It is recommended to only set the values of inputs that haven't been populated by
			//  prior users.  Inputs that already have values saved to the server will be overridden with
			//  values set in this method.
		}
	};

	vm.afterLoad = function afterLoad() {
		//  This method is called after setDefaults has been called.

		formLifecycle.afterLoad();

		ko.computed(function () {
			// Count how many checkboxes are checked
			var checkedCount = 0;

			if (vm.englishOrCommunications()) checkedCount++;
			if (vm.mathOrScience()) checkedCount++;
			if (vm.socialScience()) checkedCount++;
			if (vm.fineArtsOrHumanities()) checkedCount++;
			if (vm.writtenCommunication()) checkedCount++;

			// Require at least one checkbox to be checked
			if (checkedCount === 0) {
				// Set all checkboxes to required
				$("#englishOrCommunications").prop("required", true);
				$("#mathOrScience").prop("required", true);
				$("#socialScience").prop("required", true);
				$("#fineArtsOrHumanities").prop("required", true);
				$("#writtenCommunication").prop("required", true);
			} else {
				// At least one checkbox is checked, so set all checkboxes to not required
				$("#englishOrCommunications").prop("required", false);
				$("#mathOrScience").prop("required", false);
				$("#socialScience").prop("required", false);
				$("#fineArtsOrHumanities").prop("required", false);
				$("#writtenCommunication").prop("required", false);
			}
		});

		ko.computed(function () {
			// Count how many checkboxes are checked
			var checkedCountTwo = 0;

			if (vm.englishOrCommunications()) checkedCountTwo++;
			if (vm.mathOrScience()) checkedCountTwo++;
			if (vm.socialScience()) checkedCountTwo++;
			if (vm.fineArtsOrHumanities()) checkedCountTwo++;
			if (vm.writtenCommunication()) checkedCountTwo++;

			// Get all checkboxes
			var checkboxes = [
				"englishOrCommunications",
				"mathOrScience",
				"socialScience",
				"fineArtsOrHumanities",
				"writtenCommunication",
			];

			if (checkedCountTwo > 1) {
				// Prevent further checkbox selections
				checkboxes.forEach(function (checkboxId) {
					if (!$("#" + checkboxId).is(":checked")) {
						fieldStateUtils.setDisabled(checkboxId);
					}
				});
			} else {
				// Enable all checkboxes
				checkboxes.forEach(function (checkboxId) {
					fieldStateUtils.unlockFields([checkboxId]);
				});
			}
		});

		//start ko.computed for MTA Checkboxes
		ko.computed(function () {
			// Count how many checkboxes are checked
			var checkedCount = 0;

			if (vm.mtaEnglishComposition()) checkedCount++;
			if (vm.mtaComms()) checkedCount++;
			if (vm.mtaMath()) checkedCount++;
			if (vm.mtaSocialSciences()) checkedCount++;
			if (vm.mtaFineArtsHumanities()) checkedCount++;
			if (vm.mtaNaturalScience()) checkedCount++;

			// Require at least one checkbox to be checked
			if (checkedCount === 0) {
				// Set all checkboxes to required
				$("#mtaEnglishComposition").prop("required", true);
				$("#mtaComms").prop("required", true);
				$("#mtaMath").prop("required", true);
				$("#mtaSocialSciences").prop("required", true);
				$("#mtaFineArtsHumanities").prop("required", true);
				$("#mtaNaturalScience").prop("required", true);
			} else {
				// At least one checkbox is checked, so set all checkboxes to not required
				$("#mtaEnglishComposition").prop("required", false);
				$("#mtaComms").prop("required", false);
				$("#mtaMath").prop("required", false);
				$("#mtaSocialSciences").prop("required", false);
				$("#mtaFineArtsHumanities").prop("required", false);
				$("#mtaNaturalScience").prop("required", false);
			}
		});

		ko.computed(function () {
			// Count how many checkboxes are checked
			var checkedCountTwo = 0;

			if (vm.mtaEnglishComposition()) checkedCountTwo++;
			if (vm.mtaComms()) checkedCountTwo++;
			if (vm.mtaMath()) checkedCountTwo++;
			if (vm.mtaSocialSciences()) checkedCountTwo++;
			if (vm.mtaFineArtsHumanities()) checkedCountTwo++;
			if (vm.mtaNaturalScience()) checkedCountTwo++;

			// Get all checkboxes
			var checkboxes = [
				"mtaEnglishComposition",
				"mtaComms",
				"mtaMath",
				"mtaSocialSciences",
				"mtaFineArtsHumanities",
				"mtaNaturalScience",
			];

			if (checkedCountTwo > 1) {
				// Prevent further checkbox selections
				checkboxes.forEach(function (checkboxId) {
					if (!$("#" + checkboxId).is(":checked")) {
						fieldStateUtils.lockFields([checkboxId]);
					}
				});
			} else {
				// Enable all checkboxes
				checkboxes.forEach(function (checkboxId) {
					fieldStateUtils.unlockFields([checkboxId]);
				});
			}
		});

		//  WARNING: It is not recommended to set input values during afterLoad because it is not guaranteed
		//  to save values to the server.

		//Initialize FormBuilder created form specific code
		liveVM.afterLoadEditsForVM();

		$(".loading").hide();

		/*
        //  This is resizing the textarea's when the form loads incase it is pulling in real data.
        var ta = document.querySelector('.autosizeareas');
        var evt = document.createEvent('Event');
        evt.initEvent('autosize:update', true, false);
        ta.dispatchEvent(evt);
        */
		autosize($("textarea"));
	};

	//Submitting Lifecycle Callbacks:
	//Parameters:
	//  form.attachmentCount: integer

	//In order to stop the Submitting Lifecycle and prevent this form from moving to the next step in the workflow
	//process, add the following to any of the functions below:
	//    throw new Error('reason placed here will be displayed to the user');

	vm.onSubmit = function onSubmit(form) {
		//  This method is called when the Submit button is clicked and before calling beforeRequired.
		//  This normally occurs in the Forms Library, but may occur in the Inbox when a package is
		//  returned to Originator.
	};

	vm.onApprove = function onApprove(form) {
		//  This method is called when the Approve button is clicked and before calling beforeRequired.
	};

	vm.onDecline = function onDecline(form) {
		//  This method is called when the Decline button is clicked and before calling beforeRequired.
	};

	vm.beforeRequired = function beforeRequired(form) {
		//  This method is called after onSubmit, onApprove or onDecline and before validating the forms required fields.
		formLifecycle.beforeRequired();
	};

	vm.afterRequired = function afterRequired(form) {
		//  This method is called after the required inputs on the form have been confirmed to have values.
		formLifecycle.afterRequired();

		if (
			vm.genEdDistListChoice() === "Yes" &&
			vm.michiganTransfer() === "Yes"
		) {
			if (form.attachmentCount < 2) {
				notify("error", "You must attach Form OCC 63K and Form OCC63N");
				return false;
			}
		} else if (
			vm.genEdDistListChoice() === "Yes" &&
			form.attachmentCount < 1
		) {
			notify("error", "You must attach Form OCC 63K");
			return false;
		} else if (
			vm.michiganTransfer() === "Yes" &&
			form.attachmentCount < 1
		) {
			notify("error", "You must attach Form OCC 63N");
			return false;
		}

		if (form.attachmentCount < 1) {
			notify("error", "Please attach your copy of the Ballot Results");
			return false;
		} else {
			return true;
		}

		return true;
	};

	vm.onOptOut = function onOptOut(form) {
		//  This method is called after the required inputs on the form have been confirmed to have values.
	};

	vm.onESignSubmit = function onESignSubmit(form) {
		//  This method is called after the required inputs on the form have been confirmed to have values.
	};

	return vm;
});
